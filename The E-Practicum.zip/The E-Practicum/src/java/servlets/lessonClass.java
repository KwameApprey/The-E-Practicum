/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

/**
 *
 * @author herma
 */

//Members of the main entity onject which is lesson.
public class lessonClass {
    private String lessonCode;
    private String presenter;
    private String level;
    private String stage;
    private String subject;
    private String topic;
    private String fileName;

    //getters and setters to retrieve and store the entity members
    public String getLessonCode() {
        return lessonCode;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }

    public String getPresenter() {
        return presenter;
    }

    public void setPresenter(String presenter) {
        this.presenter = presenter;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
//constructors to create new lesson objects
    public lessonClass(String lessonCode, String presenter, String level, String stage, String subject, String topic, String fileName) {
        this.lessonCode = lessonCode;
        this.presenter = presenter;
        this.level = level;
        this.stage = stage;
        this.subject = subject;
        this.topic = topic;
        this.fileName = fileName;
    }

    public lessonClass() {
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

/**
 *
 * @author herma
 */
public class lessonArray {
    
    lessonClass[] lessons; // Array of lesson objects
    
    // The constructor creates a "hardwired" array of sample lessons
    public lessonArray() { 
        lessons = new lessonClass[3];
        lessons[0] = new lessonClass("v001", "Joseph Apprey-Hermann", "JHS", "3", "Science", "Osmosis", "videofile1");
        lessons[1] = new lessonClass("v002", "Eric Quasin", "JHS", "1", "Mathematics", "Sets", "videofile2");
        lessons[2] = new lessonClass("v003", "LaNiece Mcrey", "JHS", "2", "English", "Subject verb Aggreement", "videofile3");       
    }
    
    // Return the array of lessons, to be displayed in a JSP
    public lessonClass[] getlessons() {
        return lessons;
    }
    
    
    // Search the array of current lessons for one with the given
    // Subject and topic, and return the corresponding lesson in the array
    public lessonClass getLesson(String subject, String topic) {
        for (lessonClass c : lessons) {
            if (subject.equals(c.getSubject()) &&
                    topic.equals(c.getTopic())) {
                return c;
            }
        }
        return null;
    }
    
    
}
